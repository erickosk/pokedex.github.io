// Datos de la Pokédex: 151 Pokémon (Generación I). Edita aquí para añadir o corregir datos.
var POKEMON = [
 {
  "n": 1,
  "id": "bulbasaur",
  "nombre": "Bulbasaur",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Semilla. Lleva una semilla en el lomo desde que nace y crece junto con él al absorber la luz del sol.",
  "altura": "0.7 m",
  "peso": "6.9 kg",
  "habilidad": "Espesura"
 },
 {
  "n": 2,
  "id": "ivysaur",
  "nombre": "Ivysaur",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Semilla. El bulbo de su lomo florece cuando absorbe mucha luz solar y le da un aroma suave.",
  "altura": "1.0 m",
  "peso": "13.0 kg",
  "habilidad": "Espesura"
 },
 {
  "n": 3,
  "id": "venusaur",
  "nombre": "Venusaur",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Semilla. La gran flor de su lomo absorbe la luz del sol y la convierte en energía.",
  "altura": "2.0 m",
  "peso": "100.0 kg",
  "habilidad": "Espesura"
 },
 {
  "n": 4,
  "id": "charmander",
  "nombre": "Charmander",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Lagartija. La llama de su cola indica cómo está de salud y de ánimo. Prefiere los lugares cálidos.",
  "altura": "0.6 m",
  "peso": "8.5 kg",
  "habilidad": "Mar Llamas"
 },
 {
  "n": 5,
  "id": "charmeleon",
  "nombre": "Charmeleon",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Llama. Es agresivo y le gusta pelear; cuando se emociona, la llama de su cola arde con más fuerza.",
  "altura": "1.1 m",
  "peso": "19.0 kg",
  "habilidad": "Mar Llamas"
 },
 {
  "n": 6,
  "id": "charizard",
  "nombre": "Charizard",
  "tipos": [
   "fuego",
   "volador"
  ],
  "desc": "Pokémon Llama. Vuela por el cielo con sus grandes alas y escupe fuego muy caliente. Busca rivales fuertes para pelear.",
  "altura": "1.7 m",
  "peso": "90.5 kg",
  "habilidad": "Mar Llamas"
 },
 {
  "n": 7,
  "id": "squirtle",
  "nombre": "Squirtle",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Tortuguita. Se esconde en su caparazón para protegerse y lanza chorros de agua a sus rivales.",
  "altura": "0.5 m",
  "peso": "9.0 kg",
  "habilidad": "Torrente"
 },
 {
  "n": 8,
  "id": "wartortle",
  "nombre": "Wartortle",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Tortuga. Su cola peluda y sus orejas lo ayudan a mantener el equilibrio al nadar.",
  "altura": "1.0 m",
  "peso": "22.5 kg",
  "habilidad": "Torrente"
 },
 {
  "n": 9,
  "id": "blastoise",
  "nombre": "Blastoise",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Armazón. Dispara chorros de agua a gran presión con los cañones que tiene en su caparazón.",
  "altura": "1.6 m",
  "peso": "85.5 kg",
  "habilidad": "Torrente"
 },
 {
  "n": 10,
  "id": "caterpie",
  "nombre": "Caterpie",
  "tipos": [
   "bicho"
  ],
  "desc": "Pokémon Gusano. Come muchas hojas para crecer y usa las antenas rojas de su cabeza para espantar enemigos.",
  "altura": "0.3 m",
  "peso": "2.9 kg",
  "habilidad": "Polvo Escudo"
 },
 {
  "n": 11,
  "id": "metapod",
  "nombre": "Metapod",
  "tipos": [
   "bicho"
  ],
  "desc": "Pokémon Capullo. Se queda quieto dentro de su duro caparazón mientras su cuerpo se prepara para evolucionar.",
  "altura": "0.7 m",
  "peso": "9.9 kg",
  "habilidad": "Mudar"
 },
 {
  "n": 12,
  "id": "butterfree",
  "nombre": "Butterfree",
  "tipos": [
   "bicho",
   "volador"
  ],
  "desc": "Pokémon Mariposa. Vuela con sus alas cubiertas de un polvo que repele el agua y recoge néctar de las flores.",
  "altura": "1.1 m",
  "peso": "32.0 kg",
  "habilidad": "Ojo Compuesto"
 },
 {
  "n": 13,
  "id": "weedle",
  "nombre": "Weedle",
  "tipos": [
   "bicho",
   "veneno"
  ],
  "desc": "Pokémon Oruga Pelo. Tiene un aguijón venenoso en la cabeza y vive en bosques y pastizales comiendo hojas.",
  "altura": "0.3 m",
  "peso": "3.2 kg",
  "habilidad": "Polvo Escudo"
 },
 {
  "n": 14,
  "id": "kakuna",
  "nombre": "Kakuna",
  "tipos": [
   "bicho",
   "veneno"
  ],
  "desc": "Pokémon Capullo. Casi no se mueve y espera a evolucionar; si lo molestan, puede defenderse con su veneno.",
  "altura": "0.6 m",
  "peso": "10.0 kg",
  "habilidad": "Mudar"
 },
 {
  "n": 15,
  "id": "beedrill",
  "nombre": "Beedrill",
  "tipos": [
   "bicho",
   "veneno"
  ],
  "desc": "Pokémon Abeja Veneno. Ataca en grupo con los grandes aguijones de sus brazos y de su cola, que son muy rápidos.",
  "altura": "1.0 m",
  "peso": "29.5 kg",
  "habilidad": "Enjambre"
 },
 {
  "n": 16,
  "id": "pidgey",
  "nombre": "Pidgey",
  "tipos": [
   "normal",
   "volador"
  ],
  "desc": "Pokémon Pajarito. Es tranquilo y prefiere esconderse en la hierba. Levanta arena con sus alas para defenderse.",
  "altura": "0.3 m",
  "peso": "1.8 kg",
  "habilidad": "Vista Lince"
 },
 {
  "n": 17,
  "id": "pidgeotto",
  "nombre": "Pidgeotto",
  "tipos": [
   "normal",
   "volador"
  ],
  "desc": "Pokémon Pájaro. Vigila un gran territorio desde el aire y atrapa a sus presas con sus fuertes garras.",
  "altura": "1.1 m",
  "peso": "30.0 kg",
  "habilidad": "Vista Lince"
 },
 {
  "n": 18,
  "id": "pidgeot",
  "nombre": "Pidgeot",
  "tipos": [
   "normal",
   "volador"
  ],
  "desc": "Pokémon Pájaro. Vuela muy rápido con sus alas enormes y su cresta brillante intimida a sus enemigos.",
  "altura": "1.5 m",
  "peso": "39.5 kg",
  "habilidad": "Vista Lince"
 },
 {
  "n": 19,
  "id": "rattata",
  "nombre": "Rattata",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Ratón. Es muy veloz y come casi cualquier cosa. Sus dientes de adelante nunca dejan de crecer.",
  "altura": "0.3 m",
  "peso": "3.5 kg",
  "habilidad": "Fuga"
 },
 {
  "n": 20,
  "id": "raticate",
  "nombre": "Raticate",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Ratón. Usa sus colmillos filosos para roer cosas duras y las membranas de sus patas le ayudan a nadar.",
  "altura": "0.7 m",
  "peso": "18.5 kg",
  "habilidad": "Fuga"
 },
 {
  "n": 21,
  "id": "spearow",
  "nombre": "Spearow",
  "tipos": [
   "normal",
   "volador"
  ],
  "desc": "Pokémon Pajarito. Es muy territorial y bate sus alas sin parar para vigilar su zona. Grita fuerte para avisar del peligro.",
  "altura": "0.3 m",
  "peso": "2.0 kg",
  "habilidad": "Vista Lince"
 },
 {
  "n": 22,
  "id": "fearow",
  "nombre": "Fearow",
  "tipos": [
   "normal",
   "volador"
  ],
  "desc": "Pokémon Pico. Su largo pico le sirve para cazar presas bajo tierra. Puede volar durante todo un día sin descansar.",
  "altura": "1.2 m",
  "peso": "38.0 kg",
  "habilidad": "Vista Lince"
 },
 {
  "n": 23,
  "id": "ekans",
  "nombre": "Ekans",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Serpiente. Se enrolla para descansar y se acerca sin hacer ruido a sus presas. Cuanto más crece, más largo es su cuerpo.",
  "altura": "2.0 m",
  "peso": "6.9 kg",
  "habilidad": "Intimidación"
 },
 {
  "n": 24,
  "id": "arbok",
  "nombre": "Arbok",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Cobra. Infla su cuello para mostrar el dibujo de su vientre y asustar a sus rivales. Su mordisco es muy venenoso.",
  "altura": "3.5 m",
  "peso": "65.0 kg",
  "habilidad": "Intimidación"
 },
 {
  "n": 25,
  "id": "pikachu",
  "nombre": "Pikachu",
  "tipos": [
   "electrico"
  ],
  "desc": "Pokémon Ratón. Guarda electricidad en las bolsas rojas de sus mejillas y la libera cuando se siente en peligro.",
  "altura": "0.4 m",
  "peso": "6.0 kg",
  "habilidad": "Elec. Estática"
 },
 {
  "n": 26,
  "id": "raichu",
  "nombre": "Raichu",
  "tipos": [
   "electrico"
  ],
  "desc": "Pokémon Ratón. Su cola larga le sirve de descarga a tierra. Si acumula demasiada electricidad se vuelve agresivo.",
  "altura": "0.8 m",
  "peso": "30.0 kg",
  "habilidad": "Elec. Estática"
 },
 {
  "n": 27,
  "id": "sandshrew",
  "nombre": "Sandshrew",
  "tipos": [
   "tierra"
  ],
  "desc": "Pokémon Ratón. Vive en zonas áridas y se hace bolita para protegerse. Cava túneles profundos para guardar su comida.",
  "altura": "0.6 m",
  "peso": "12.0 kg",
  "habilidad": "Velo Arena"
 },
 {
  "n": 28,
  "id": "sandslash",
  "nombre": "Sandslash",
  "tipos": [
   "tierra"
  ],
  "desc": "Pokémon Ratón. Todo su cuerpo está cubierto de púas duras. Se hace una bola con ellas y rueda para atacar.",
  "altura": "1.0 m",
  "peso": "29.5 kg",
  "habilidad": "Velo Arena"
 },
 {
  "n": 29,
  "id": "nidoran-f",
  "nombre": "Nidoran♀",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Veneno Pin. Es pequeña pero sus púas tienen veneno. Sus orejas grandes detectan los sonidos más leves.",
  "altura": "0.4 m",
  "peso": "7.0 kg",
  "habilidad": "Punto Tóxico"
 },
 {
  "n": 30,
  "id": "nidorina",
  "nombre": "Nidorina",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Veneno Pin. Es tranquila y cuida mucho a su grupo. Sus cuernos son pequeños y le molestan al comer.",
  "altura": "0.8 m",
  "peso": "20.0 kg",
  "habilidad": "Punto Tóxico"
 },
 {
  "n": 31,
  "id": "nidoqueen",
  "nombre": "Nidoqueen",
  "tipos": [
   "veneno",
   "tierra"
  ],
  "desc": "Pokémon Taladro. Su cuerpo está cubierto de escamas muy duras. Protege a sus crías con todas sus fuerzas.",
  "altura": "1.3 m",
  "peso": "60.0 kg",
  "habilidad": "Punto Tóxico"
 },
 {
  "n": 32,
  "id": "nidoran-m",
  "nombre": "Nidoran♂",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Veneno Pin. Sus grandes orejas se mueven para detectar el peligro. Su cuerno pequeño lanza un veneno potente.",
  "altura": "0.5 m",
  "peso": "9.0 kg",
  "habilidad": "Punto Tóxico"
 },
 {
  "n": 33,
  "id": "nidorino",
  "nombre": "Nidorino",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Veneno Pin. Tiene un carácter violento y ataca con su cuerno, que es más duro que un diamante.",
  "altura": "0.9 m",
  "peso": "19.5 kg",
  "habilidad": "Punto Tóxico"
 },
 {
  "n": 34,
  "id": "nidoking",
  "nombre": "Nidoking",
  "tipos": [
   "veneno",
   "tierra"
  ],
  "desc": "Pokémon Taladro. Su gruesa cola es muy potente y puede derribar una torre de metal. Cuando se enfurece nadie lo detiene.",
  "altura": "1.4 m",
  "peso": "62.0 kg",
  "habilidad": "Punto Tóxico"
 },
 {
  "n": 35,
  "id": "clefairy",
  "nombre": "Clefairy",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Hada. Es tan adorable que todos quieren cuidarlo. Se dice que baila bajo la luz de la luna llena.",
  "altura": "0.6 m",
  "peso": "7.5 kg",
  "habilidad": "Gran Encanto"
 },
 {
  "n": 36,
  "id": "clefable",
  "nombre": "Clefable",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Hada. Es tímido y casi nunca se deja ver. Sus enormes orejas oyen un alfiler caer a mucha distancia.",
  "altura": "1.3 m",
  "peso": "40.0 kg",
  "habilidad": "Gran Encanto"
 },
 {
  "n": 37,
  "id": "vulpix",
  "nombre": "Vulpix",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Zorro. Al nacer tiene una sola cola, y se le van dividiendo en seis al crecer. Su cuerpo siempre está calientito.",
  "altura": "0.6 m",
  "peso": "9.9 kg",
  "habilidad": "Absorbe Fuego"
 },
 {
  "n": 38,
  "id": "ninetales",
  "nombre": "Ninetales",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Zorro. Tiene nueve colas muy hermosas. Se dice que puede vivir mil años.",
  "altura": "1.1 m",
  "peso": "19.9 kg",
  "habilidad": "Absorbe Fuego"
 },
 {
  "n": 39,
  "id": "jigglypuff",
  "nombre": "Jigglypuff",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Globo. Sus ojos grandes y redondos hipnotizan. Canta una melodía que hace dormir a todos los que la escuchan.",
  "altura": "0.5 m",
  "peso": "5.5 kg",
  "habilidad": "Gran Encanto"
 },
 {
  "n": 40,
  "id": "wigglytuff",
  "nombre": "Wigglytuff",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Globo. Su pelaje es muy suave y esponjoso. Si respira hondo puede inflar su cuerpo como un globo.",
  "altura": "1.0 m",
  "peso": "12.0 kg",
  "habilidad": "Gran Encanto"
 },
 {
  "n": 41,
  "id": "zubat",
  "nombre": "Zubat",
  "tipos": [
   "veneno",
   "volador"
  ],
  "desc": "Pokémon Murciélago. No tiene ojos: se orienta en la oscuridad con ondas ultrasónicas que emite por la boca.",
  "altura": "0.8 m",
  "peso": "7.5 kg",
  "habilidad": "Foco Interno"
 },
 {
  "n": 42,
  "id": "golbat",
  "nombre": "Golbat",
  "tipos": [
   "veneno",
   "volador"
  ],
  "desc": "Pokémon Murciélago. Muerde con sus colmillos para chupar sangre y puede beber más de lo que cabe en su cuerpo.",
  "altura": "1.6 m",
  "peso": "55.0 kg",
  "habilidad": "Foco Interno"
 },
 {
  "n": 43,
  "id": "oddish",
  "nombre": "Oddish",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Hierbajo. De día se esconde bajo tierra; de noche camina por ahí y esparce sus semillas.",
  "altura": "0.5 m",
  "peso": "5.4 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 44,
  "id": "gloom",
  "nombre": "Gloom",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Hierbajo. De su pistilo gotea una miel de olor tan fuerte que marea a quien se acerca.",
  "altura": "0.8 m",
  "peso": "8.6 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 45,
  "id": "vileplume",
  "nombre": "Vileplume",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Flor. Tiene los pétalos más grandes del mundo Pokémon y los sacude para esparcir polen venenoso.",
  "altura": "1.2 m",
  "peso": "18.6 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 46,
  "id": "paras",
  "nombre": "Paras",
  "tipos": [
   "bicho",
   "planta"
  ],
  "desc": "Pokémon Hongo. Lleva dos setas en el lomo que crecen alimentándose de los nutrientes de su cuerpo.",
  "altura": "0.3 m",
  "peso": "5.4 kg",
  "habilidad": "Efecto Espora"
 },
 {
  "n": 47,
  "id": "parasect",
  "nombre": "Parasect",
  "tipos": [
   "bicho",
   "planta"
  ],
  "desc": "Pokémon Hongo. La seta gigante de su lomo controla su cuerpo: el bicho en sí es solo su huésped.",
  "altura": "1.0 m",
  "peso": "29.5 kg",
  "habilidad": "Efecto Espora"
 },
 {
  "n": 48,
  "id": "venonat",
  "nombre": "Venonat",
  "tipos": [
   "bicho",
   "veneno"
  ],
  "desc": "Pokémon Insecto. Sus grandes ojos funcionan como radares y disparan rayos de luz cuando detecta enemigos.",
  "altura": "1.0 m",
  "peso": "30.0 kg",
  "habilidad": "Ojo Compuesto"
 },
 {
  "n": 49,
  "id": "venomoth",
  "nombre": "Venomoth",
  "tipos": [
   "bicho",
   "veneno"
  ],
  "desc": "Pokémon Polilla. Las escamas de sus alas se desprenden al batirlas y son un veneno muy peligroso.",
  "altura": "1.5 m",
  "peso": "12.5 kg",
  "habilidad": "Polvo Escudo"
 },
 {
  "n": 50,
  "id": "diglett",
  "nombre": "Diglett",
  "tipos": [
   "tierra"
  ],
  "desc": "Pokémon Topo. Vive a un metro bajo tierra y cava túneles que remueven el suelo y ayudan a los cultivos.",
  "altura": "0.2 m",
  "peso": "0.8 kg",
  "habilidad": "Velo Arena"
 },
 {
  "n": 51,
  "id": "dugtrio",
  "nombre": "Dugtrio",
  "tipos": [
   "tierra"
  ],
  "desc": "Pokémon Topo. Son tres Diglett que cavan a la vez: sus túneles pueden llegar a 100 metros de profundidad.",
  "altura": "0.7 m",
  "peso": "33.3 kg",
  "habilidad": "Velo Arena"
 },
 {
  "n": 52,
  "id": "meowth",
  "nombre": "Meowth",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Gato Arañazo. Le gustan los objetos que brillan y suele recoger monedas para llevárselas a casa.",
  "altura": "0.4 m",
  "peso": "4.2 kg",
  "habilidad": "Recogida"
 },
 {
  "n": 53,
  "id": "persian",
  "nombre": "Persian",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Gato Fino. Tiene un pelaje suave y elegante, pero se vuelve muy agresivo cuando lo tocan en la cola.",
  "altura": "1.0 m",
  "peso": "32.0 kg",
  "habilidad": "Flexibilidad"
 },
 {
  "n": 54,
  "id": "psyduck",
  "nombre": "Psyduck",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Pato. Siempre sufre dolores de cabeza; cuando son muy fuertes, descubre poderes misteriosos.",
  "altura": "0.8 m",
  "peso": "19.6 kg",
  "habilidad": "Humedad"
 },
 {
  "n": 55,
  "id": "golduck",
  "nombre": "Golduck",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Pato. Es un nadador excelente: se desliza por el agua con sus patas palmeadas, incluso con oleaje.",
  "altura": "1.7 m",
  "peso": "76.6 kg",
  "habilidad": "Humedad"
 },
 {
  "n": 56,
  "id": "mankey",
  "nombre": "Mankey",
  "tipos": [
   "lucha"
  ],
  "desc": "Pokémon Mono Cerdo. Es muy ágil e irascible, y se enfurece sin motivo; si se enfada, se vuelve incontrolable.",
  "altura": "0.5 m",
  "peso": "28.0 kg",
  "habilidad": "Espíritu Vital"
 },
 {
  "n": 57,
  "id": "primeape",
  "nombre": "Primeape",
  "tipos": [
   "lucha"
  ],
  "desc": "Pokémon Mono Cerdo. Su ira nunca termina: persigue sin descanso a quien le provoca hasta quedar agotado.",
  "altura": "1.0 m",
  "peso": "32.0 kg",
  "habilidad": "Espíritu Vital"
 },
 {
  "n": 58,
  "id": "growlithe",
  "nombre": "Growlithe",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Cachorro. Es muy leal y valiente: ladra con fiereza para proteger a su entrenador de cualquier amenaza.",
  "altura": "0.7 m",
  "peso": "19.0 kg",
  "habilidad": "Intimidación"
 },
 {
  "n": 59,
  "id": "arcanine",
  "nombre": "Arcanine",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Legendario. Corre tan rápido que parece volar y es famoso desde hace siglos por su belleza y su elegancia.",
  "altura": "1.9 m",
  "peso": "155.0 kg",
  "habilidad": "Intimidación"
 },
 {
  "n": 60,
  "id": "poliwag",
  "nombre": "Poliwag",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Renacuajo. La espiral de su vientre es su intestino visto a través de la piel; es mejor nadando que andando.",
  "altura": "0.6 m",
  "peso": "12.4 kg",
  "habilidad": "Absorbe Agua"
 },
 {
  "n": 61,
  "id": "poliwhirl",
  "nombre": "Poliwhirl",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Renacuajo. Suda sin parar para que su piel esté húmeda y resbaladiza, así evita que lo atrapen.",
  "altura": "1.0 m",
  "peso": "20.0 kg",
  "habilidad": "Absorbe Agua"
 },
 {
  "n": 62,
  "id": "poliwrath",
  "nombre": "Poliwrath",
  "tipos": [
   "agua",
   "lucha"
  ],
  "desc": "Pokémon Renacuajo. Tiene músculos muy fuertes y es un gran nadador: cruza el océano a golpe de brazada.",
  "altura": "1.3 m",
  "peso": "54.0 kg",
  "habilidad": "Absorbe Agua"
 },
 {
  "n": 63,
  "id": "abra",
  "nombre": "Abra",
  "tipos": [
   "psiquico"
  ],
  "desc": "Pokémon Psi. Duerme unas dieciocho horas al día, pero incluso dormido usa sus poderes y se teletransporta.",
  "altura": "0.9 m",
  "peso": "19.5 kg",
  "habilidad": "Sincronía"
 },
 {
  "n": 64,
  "id": "kadabra",
  "nombre": "Kadabra",
  "tipos": [
   "psiquico"
  ],
  "desc": "Pokémon Psi. Emite ondas alfa especiales que provocan dolor de cabeza a quienes están cerca.",
  "altura": "1.3 m",
  "peso": "56.5 kg",
  "habilidad": "Sincronía"
 },
 {
  "n": 65,
  "id": "alakazam",
  "nombre": "Alakazam",
  "tipos": [
   "psiquico"
  ],
  "desc": "Pokémon Psi. Su cerebro crece sin parar y su coeficiente intelectual supera los 5000; lo recuerda todo.",
  "altura": "1.5 m",
  "peso": "48.0 kg",
  "habilidad": "Sincronía"
 },
 {
  "n": 66,
  "id": "machop",
  "nombre": "Machop",
  "tipos": [
   "lucha"
  ],
  "desc": "Pokémon Superpoder. Aunque es pequeño, es muy fuerte: puede levantar cien veces su peso sin esfuerzo.",
  "altura": "0.8 m",
  "peso": "19.5 kg",
  "habilidad": "Agallas"
 },
 {
  "n": 67,
  "id": "machoke",
  "nombre": "Machoke",
  "tipos": [
   "lucha"
  ],
  "desc": "Pokémon Superpoder. Su cuerpo es de puro músculo; lleva un cinturón que frena su enorme fuerza.",
  "altura": "1.5 m",
  "peso": "70.5 kg",
  "habilidad": "Agallas"
 },
 {
  "n": 68,
  "id": "machamp",
  "nombre": "Machamp",
  "tipos": [
   "lucha"
  ],
  "desc": "Pokémon Superpoder. Con sus cuatro brazos lanza cien golpes en dos segundos, pero a veces los usa para otras tareas.",
  "altura": "1.6 m",
  "peso": "130.0 kg",
  "habilidad": "Agallas"
 },
 {
  "n": 69,
  "id": "bellsprout",
  "nombre": "Bellsprout",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Flor. Tiene un cuerpo delgado y flexible que se mece con el viento para esquivar ataques.",
  "altura": "0.7 m",
  "peso": "4.0 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 70,
  "id": "weepinbell",
  "nombre": "Weepinbell",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Mosca. Su gran boca atrapa insectos y los disuelve con un líquido ácido que escupe sin parar.",
  "altura": "1.0 m",
  "peso": "6.4 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 71,
  "id": "victreebel",
  "nombre": "Victreebel",
  "tipos": [
   "planta",
   "veneno"
  ],
  "desc": "Pokémon Mosca. Atrae a sus presas con un dulce aroma, las traga enteras y las disuelve durante días.",
  "altura": "1.7 m",
  "peso": "15.5 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 72,
  "id": "tentacool",
  "nombre": "Tentacool",
  "tipos": [
   "agua",
   "veneno"
  ],
  "desc": "Pokémon Medusa. Su cuerpo es casi todo agua; flota en el mar y atrapa a sus presas con tentáculos venenosos.",
  "altura": "0.9 m",
  "peso": "45.5 kg",
  "habilidad": "Cuerpo Puro"
 },
 {
  "n": 73,
  "id": "tentacruel",
  "nombre": "Tentacruel",
  "tipos": [
   "agua",
   "veneno"
  ],
  "desc": "Pokémon Medusa. Tiene 80 tentáculos que se estiran y se encogen para inmovilizar a sus presas con veneno.",
  "altura": "1.6 m",
  "peso": "55.0 kg",
  "habilidad": "Cuerpo Puro"
 },
 {
  "n": 74,
  "id": "geodude",
  "nombre": "Geodude",
  "tipos": [
   "roca",
   "tierra"
  ],
  "desc": "Pokémon Roca. Se confunde con las piedras del camino y a veces la gente le pisa sin darse cuenta.",
  "altura": "0.4 m",
  "peso": "20.0 kg",
  "habilidad": "Cabeza Roca"
 },
 {
  "n": 75,
  "id": "graveler",
  "nombre": "Graveler",
  "tipos": [
   "roca",
   "tierra"
  ],
  "desc": "Pokémon Roca. Rueda por las pendientes y arrasa con todo lo que se cruza, sin parar hasta el pie del monte.",
  "altura": "1.0 m",
  "peso": "105.0 kg",
  "habilidad": "Cabeza Roca"
 },
 {
  "n": 76,
  "id": "golem",
  "nombre": "Golem",
  "tipos": [
   "roca",
   "tierra"
  ],
  "desc": "Pokémon Mole. Su cuerpo es duro como una roca y muda de caparazón una vez al año para renovarlo.",
  "altura": "1.4 m",
  "peso": "300.0 kg",
  "habilidad": "Cabeza Roca"
 },
 {
  "n": 77,
  "id": "ponyta",
  "nombre": "Ponyta",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Caballo Fuego. Al nacer tiene las patas débiles, pero a fuerza de correr se hace veloz y su crin arde.",
  "altura": "1.0 m",
  "peso": "30.0 kg",
  "habilidad": "Fuga"
 },
 {
  "n": 78,
  "id": "rapidash",
  "nombre": "Rapidash",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Caballo Fuego. Galopa a más de 240 km/h y su crin de fuego arde con más fuerza al correr.",
  "altura": "1.7 m",
  "peso": "95.0 kg",
  "habilidad": "Fuga"
 },
 {
  "n": 79,
  "id": "slowpoke",
  "nombre": "Slowpoke",
  "tipos": [
   "agua",
   "psiquico"
  ],
  "desc": "Pokémon Atontado. Es tan lento que tarda en notar el dolor: pesca con la cola y no se entera de que le muerden.",
  "altura": "1.2 m",
  "peso": "36.0 kg",
  "habilidad": "Despiste"
 },
 {
  "n": 80,
  "id": "slowbro",
  "nombre": "Slowbro",
  "tipos": [
   "agua",
   "psiquico"
  ],
  "desc": "Pokémon Hermitaño. Un Shellder se le ha agarrado a la cola y le provoca una forma de evolución muy peculiar.",
  "altura": "1.6 m",
  "peso": "78.5 kg",
  "habilidad": "Despiste"
 },
 {
  "n": 81,
  "id": "magnemite",
  "nombre": "Magnemite",
  "tipos": [
   "electrico"
  ],
  "desc": "Pokémon Imán. Flota gracias a ondas electromagnéticas y absorbe electricidad de las líneas de alta tensión.",
  "altura": "0.3 m",
  "peso": "6.0 kg",
  "habilidad": "Imán"
 },
 {
  "n": 82,
  "id": "magneton",
  "nombre": "Magneton",
  "tipos": [
   "electrico"
  ],
  "desc": "Pokémon Imán. Son tres Magnemite unidos; emiten un fuerte campo magnético que estropea los aparatos cercanos.",
  "altura": "1.0 m",
  "peso": "60.0 kg",
  "habilidad": "Imán"
 },
 {
  "n": 83,
  "id": "farfetchd",
  "nombre": "Farfetch'd",
  "tipos": [
   "normal",
   "volador"
  ],
  "desc": "Pokémon Pato Salvaje. Siempre lleva un puerro, que usa como arma, y lo defiende con gran determinación.",
  "altura": "0.8 m",
  "peso": "15.0 kg",
  "habilidad": "Vista Lince"
 },
 {
  "n": 84,
  "id": "doduo",
  "nombre": "Doduo",
  "tipos": [
   "normal",
   "volador"
  ],
  "desc": "Pokémon Ave Gemela. Sus dos cabezas comparten la misma información: nunca duerme las dos a la vez para vigilar.",
  "altura": "1.4 m",
  "peso": "39.2 kg",
  "habilidad": "Fuga"
 },
 {
  "n": 85,
  "id": "dodrio",
  "nombre": "Dodrio",
  "tipos": [
   "normal",
   "volador"
  ],
  "desc": "Pokémon Ave Trío. Sus tres cabezas piensan y sienten por separado, y corre muy rápido por llanuras y praderas.",
  "altura": "1.8 m",
  "peso": "85.2 kg",
  "habilidad": "Fuga"
 },
 {
  "n": 86,
  "id": "seel",
  "nombre": "Seel",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Foca. Le encanta el frío: nada con agilidad bajo el hielo y se mantiene calentito gracias a su grasa.",
  "altura": "1.1 m",
  "peso": "90.0 kg",
  "habilidad": "Sebo"
 },
 {
  "n": 87,
  "id": "dewgong",
  "nombre": "Dewgong",
  "tipos": [
   "agua",
   "hielo"
  ],
  "desc": "Pokémon León Marino. Su cuerpo blanco le camufla en la nieve; se desliza por el agua helada con gracia.",
  "altura": "1.7 m",
  "peso": "120.0 kg",
  "habilidad": "Sebo"
 },
 {
  "n": 88,
  "id": "grimer",
  "nombre": "Grimer",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Lodo. Nació del lodo contaminado y su cuerpo está compuesto por sustancias tóxicas y desechos.",
  "altura": "0.9 m",
  "peso": "30.0 kg",
  "habilidad": "Hedor"
 },
 {
  "n": 89,
  "id": "muk",
  "nombre": "Muk",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Lodo. Su cuerpo desprende un hedor insoportable y deja sin vida la vegetación por donde pasa.",
  "altura": "1.2 m",
  "peso": "30.0 kg",
  "habilidad": "Hedor"
 },
 {
  "n": 90,
  "id": "shellder",
  "nombre": "Shellder",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Bivalvo. Está protegido por una concha más dura que un diamante; solo es blando por dentro.",
  "altura": "0.3 m",
  "peso": "4.0 kg",
  "habilidad": "Armadura Concha"
 },
 {
  "n": 91,
  "id": "cloyster",
  "nombre": "Cloyster",
  "tipos": [
   "agua",
   "hielo"
  ],
  "desc": "Pokémon Bivalvo. Su concha es tan dura que ni la explosión de una bomba la rompe; solo se abre para atacar.",
  "altura": "1.5 m",
  "peso": "132.5 kg",
  "habilidad": "Armadura Concha"
 },
 {
  "n": 92,
  "id": "gastly",
  "nombre": "Gastly",
  "tipos": [
   "fantasma",
   "veneno"
  ],
  "desc": "Pokémon Gas. Su cuerpo casi invisible es de gas: puede dormir a sus rivales con solo envolverlos.",
  "altura": "1.3 m",
  "peso": "0.1 kg",
  "habilidad": "Levitación"
 },
 {
  "n": 93,
  "id": "haunter",
  "nombre": "Haunter",
  "tipos": [
   "fantasma",
   "veneno"
  ],
  "desc": "Pokémon Gas. Lame a sus víctimas con su lengua gaseosa para quitarles energía vital poco a poco.",
  "altura": "1.6 m",
  "peso": "0.1 kg",
  "habilidad": "Levitación"
 },
 {
  "n": 94,
  "id": "gengar",
  "nombre": "Gengar",
  "tipos": [
   "fantasma",
   "veneno"
  ],
  "desc": "Pokémon Sombra. Se esconde en la oscuridad y baja la temperatura del ambiente unos grados al acercarse.",
  "altura": "1.5 m",
  "peso": "40.5 kg",
  "habilidad": "Levitación"
 },
 {
  "n": 95,
  "id": "onix",
  "nombre": "Onix",
  "tipos": [
   "roca",
   "tierra"
  ],
  "desc": "Pokémon Serpiente Roca. Excava bajo tierra a 80 km/h y su cuerpo se endurece como un diamante con el tiempo.",
  "altura": "8.8 m",
  "peso": "210.0 kg",
  "habilidad": "Cabeza Roca"
 },
 {
  "n": 96,
  "id": "drowzee",
  "nombre": "Drowzee",
  "tipos": [
   "psiquico"
  ],
  "desc": "Pokémon Hipnosis. Come los sueños de las personas dormidas con su trompa y se alimenta de ellos.",
  "altura": "1.0 m",
  "peso": "32.4 kg",
  "habilidad": "Insomnio"
 },
 {
  "n": 97,
  "id": "hypno",
  "nombre": "Hypno",
  "tipos": [
   "psiquico"
  ],
  "desc": "Pokémon Hipnosis. Lleva un péndulo con el que hipnotiza a los demás; a los niños dormidos se los lleva.",
  "altura": "1.6 m",
  "peso": "75.6 kg",
  "habilidad": "Insomnio"
 },
 {
  "n": 98,
  "id": "krabby",
  "nombre": "Krabby",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Cangrejo Río. Vive en las playas y excava madrigueras; sus pinzas vuelven a crecer si las pierde.",
  "altura": "0.4 m",
  "peso": "6.5 kg",
  "habilidad": "Corte Vigor"
 },
 {
  "n": 99,
  "id": "kingler",
  "nombre": "Kingler",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Pinza. Su pinza gigante tiene una fuerza de 10 000 caballos, pero es tan pesada que le cuesta mover.",
  "altura": "1.3 m",
  "peso": "60.0 kg",
  "habilidad": "Corte Vigor"
 },
 {
  "n": 100,
  "id": "voltorb",
  "nombre": "Voltorb",
  "tipos": [
   "electrico"
  ],
  "desc": "Pokémon Bola. Se parece a una Poké Ball y explota con una chispa; algunos se acumulan en las centrales eléctricas.",
  "altura": "0.5 m",
  "peso": "10.4 kg",
  "habilidad": "Insonorizar"
 },
 {
  "n": 101,
  "id": "electrode",
  "nombre": "Electrode",
  "tipos": [
   "electrico"
  ],
  "desc": "Pokémon Bola. Almacena mucha electricidad y explota con el mínimo estímulo; rueda a gran velocidad.",
  "altura": "1.2 m",
  "peso": "66.6 kg",
  "habilidad": "Insonorizar"
 },
 {
  "n": 102,
  "id": "exeggcute",
  "nombre": "Exeggcute",
  "tipos": [
   "planta",
   "psiquico"
  ],
  "desc": "Pokémon Huevo. Seis huevos que se comunican por telepatía; se unen para protegerse cuando algo se acerca.",
  "altura": "0.4 m",
  "peso": "2.5 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 103,
  "id": "exeggutor",
  "nombre": "Exeggutor",
  "tipos": [
   "planta",
   "psiquico"
  ],
  "desc": "Pokémon Coco. Cada una de sus cabezas piensa por su cuenta; los cocos crecen en la copa de su cuerpo.",
  "altura": "2.0 m",
  "peso": "120.0 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 104,
  "id": "cubone",
  "nombre": "Cubone",
  "tipos": [
   "tierra"
  ],
  "desc": "Pokémon Solitario. Lleva el cráneo de su madre fallecida y llora en la noche añorando su recuerdo.",
  "altura": "0.4 m",
  "peso": "6.5 kg",
  "habilidad": "Cabeza Roca"
 },
 {
  "n": 105,
  "id": "marowak",
  "nombre": "Marowak",
  "tipos": [
   "tierra"
  ],
  "desc": "Pokémon Huesudo. Lanza su hueso como un bumerán con gran puntería y ha superado la tristeza de su infancia.",
  "altura": "1.0 m",
  "peso": "45.0 kg",
  "habilidad": "Cabeza Roca"
 },
 {
  "n": 106,
  "id": "hitmonlee",
  "nombre": "Hitmonlee",
  "tipos": [
   "lucha"
  ],
  "desc": "Pokémon Patada. Sus piernas se estiran y encogen; sus patadas pueden derribar un camión.",
  "altura": "1.5 m",
  "peso": "49.8 kg",
  "habilidad": "Flexibilidad"
 },
 {
  "n": 107,
  "id": "hitmonchan",
  "nombre": "Hitmonchan",
  "tipos": [
   "lucha"
  ],
  "desc": "Pokémon Puñetazo. Sus puñetazos son tan rápidos como el viento y rompen el hormigón con facilidad.",
  "altura": "1.4 m",
  "peso": "50.2 kg",
  "habilidad": "Vista Lince"
 },
 {
  "n": 108,
  "id": "lickitung",
  "nombre": "Lickitung",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Lametón. Su lengua mide el doble que su cuerpo y la usa para atrapar cosas y asustar a sus rivales.",
  "altura": "1.2 m",
  "peso": "65.5 kg",
  "habilidad": "Despiste"
 },
 {
  "n": 109,
  "id": "koffing",
  "nombre": "Koffing",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Gas Venenoso. Su cuerpo está lleno de gases tóxicos que mezclan basura y bacterias para crecer.",
  "altura": "0.6 m",
  "peso": "1.0 kg",
  "habilidad": "Levitación"
 },
 {
  "n": 110,
  "id": "weezing",
  "nombre": "Weezing",
  "tipos": [
   "veneno"
  ],
  "desc": "Pokémon Gas Venenoso. Dos Koffing unidos que combinan sus gases para aumentar su toxicidad.",
  "altura": "1.2 m",
  "peso": "9.5 kg",
  "habilidad": "Levitación"
 },
 {
  "n": 111,
  "id": "rhyhorn",
  "nombre": "Rhyhorn",
  "tipos": [
   "tierra",
   "roca"
  ],
  "desc": "Pokémon Pincho. Es muy fuerte pero poco inteligente: embiste de frente hasta romper lo que tenga delante.",
  "altura": "1.0 m",
  "peso": "115.0 kg",
  "habilidad": "Pararrayos"
 },
 {
  "n": 112,
  "id": "rhydon",
  "nombre": "Rhydon",
  "tipos": [
   "tierra",
   "roca"
  ],
  "desc": "Pokémon Taladro. Camina sobre las patas traseras y su cuerno taladra rocas y hasta el diamante.",
  "altura": "1.9 m",
  "peso": "120.0 kg",
  "habilidad": "Pararrayos"
 },
 {
  "n": 113,
  "id": "chansey",
  "nombre": "Chansey",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Huevo. Pone huevos muy nutritivos y deliciosos que regala a quienes están heridos o enfermos.",
  "altura": "1.1 m",
  "peso": "34.6 kg",
  "habilidad": "Cura Natural"
 },
 {
  "n": 114,
  "id": "tangela",
  "nombre": "Tangela",
  "tipos": [
   "planta"
  ],
  "desc": "Pokémon Enredo. Está cubierto de enredaderas azules; si se las arrancan, le vuelven a crecer enseguida.",
  "altura": "1.0 m",
  "peso": "35.0 kg",
  "habilidad": "Clorofila"
 },
 {
  "n": 115,
  "id": "kangaskhan",
  "nombre": "Kangaskhan",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Maternal. Lleva a su cría en la bolsa y la protege con ferocidad; ataca con fuerza si la amenazan.",
  "altura": "2.2 m",
  "peso": "80.0 kg",
  "habilidad": "Madrugar"
 },
 {
  "n": 116,
  "id": "horsea",
  "nombre": "Horsea",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Dragón Marino. Lanza tinta para escapar y se agarra con la cola a las algas del fondo marino.",
  "altura": "0.4 m",
  "peso": "8.0 kg",
  "habilidad": "Nado Rápido"
 },
 {
  "n": 117,
  "id": "seadra",
  "nombre": "Seadra",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Dragón Marino. Sus espinas son venenosas; crea remolinos que hunden barcos para atrapar a sus presas.",
  "altura": "1.2 m",
  "peso": "25.0 kg",
  "habilidad": "Punto Tóxico"
 },
 {
  "n": 118,
  "id": "goldeen",
  "nombre": "Goldeen",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Pez Dorado. Nada con elegancia moviendo sus aletas como un vestido; su cuerno es una potente arma.",
  "altura": "0.6 m",
  "peso": "15.0 kg",
  "habilidad": "Nado Rápido"
 },
 {
  "n": 119,
  "id": "seaking",
  "nombre": "Seaking",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Pez Dorado. En otoño cava nidos en los ríos con su cuerno y lo defiende de los intrusos.",
  "altura": "1.3 m",
  "peso": "39.0 kg",
  "habilidad": "Nado Rápido"
 },
 {
  "n": 120,
  "id": "staryu",
  "nombre": "Staryu",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Estrella. Su núcleo rojo brilla por la noche; si pierde un brazo, le vuelve a crecer.",
  "altura": "0.8 m",
  "peso": "34.5 kg",
  "habilidad": "Iluminación"
 },
 {
  "n": 121,
  "id": "starmie",
  "nombre": "Starmie",
  "tipos": [
   "agua",
   "psiquico"
  ],
  "desc": "Pokémon Misterioso. Su núcleo emite luces de siete colores y se cree que envía señales al espacio.",
  "altura": "1.1 m",
  "peso": "80.0 kg",
  "habilidad": "Iluminación"
 },
 {
  "n": 122,
  "id": "mr-mime",
  "nombre": "Mr. Mime",
  "tipos": [
   "psiquico"
  ],
  "desc": "Pokémon Barrera. Crea paredes invisibles con sus pantomimas; sus movimientos hacen creer que existen.",
  "altura": "1.3 m",
  "peso": "54.5 kg",
  "habilidad": "Insonorizar"
 },
 {
  "n": 123,
  "id": "scyther",
  "nombre": "Scyther",
  "tipos": [
   "bicho",
   "volador"
  ],
  "desc": "Pokémon Mantis. Sus guadañas cortan casi todo; se mueve tan rápido que parece que hay dos de él.",
  "altura": "1.5 m",
  "peso": "56.0 kg",
  "habilidad": "Enjambre"
 },
 {
  "n": 124,
  "id": "jynx",
  "nombre": "Jynx",
  "tipos": [
   "hielo",
   "psiquico"
  ],
  "desc": "Pokémon Humanoide. Se mueve como si bailara y emite sonidos parecidos al lenguaje humano.",
  "altura": "1.4 m",
  "peso": "40.6 kg",
  "habilidad": "Despiste"
 },
 {
  "n": 125,
  "id": "electabuzz",
  "nombre": "Electabuzz",
  "tipos": [
   "electrico"
  ],
  "desc": "Pokémon Eléctrico. Se siente atraído por los transformadores y absorbe la energía de las centrales.",
  "altura": "1.1 m",
  "peso": "30.0 kg",
  "habilidad": "Elec. Estática"
 },
 {
  "n": 126,
  "id": "magmar",
  "nombre": "Magmar",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Escupefuego. Nació en un volcán y su cuerpo está cubierto de llamas que alcanzan los 1200 ºC.",
  "altura": "1.3 m",
  "peso": "44.5 kg",
  "habilidad": "Cuerpo Llama"
 },
 {
  "n": 127,
  "id": "pinsir",
  "nombre": "Pinsir",
  "tipos": [
   "bicho"
  ],
  "desc": "Pokémon Escarabajo. Atrapa a sus presas con las pinzas de su cabeza y no las suelta hasta partirlas en dos.",
  "altura": "1.5 m",
  "peso": "55.0 kg",
  "habilidad": "Corte Vigor"
 },
 {
  "n": 128,
  "id": "tauros",
  "nombre": "Tauros",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Toro Salvaje. Se golpea con sus tres colas para enfurecerse y embiste a sus rivales a gran velocidad.",
  "altura": "1.4 m",
  "peso": "88.4 kg",
  "habilidad": "Intimidación"
 },
 {
  "n": 129,
  "id": "magikarp",
  "nombre": "Magikarp",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Pez. Es débil y solo sabe chapotear; aun así, sobrevive en cualquier río o mar gracias a su fuerza vital.",
  "altura": "0.9 m",
  "peso": "10.0 kg",
  "habilidad": "Nado Rápido"
 },
 {
  "n": 130,
  "id": "gyarados",
  "nombre": "Gyarados",
  "tipos": [
   "agua",
   "volador"
  ],
  "desc": "Pokémon Atroz. Es muy violento: cuando se enfurece, arrasa ciudades y no se calma hasta quemarlo todo.",
  "altura": "6.5 m",
  "peso": "235.0 kg",
  "habilidad": "Intimidación"
 },
 {
  "n": 131,
  "id": "lapras",
  "nombre": "Lapras",
  "tipos": [
   "agua",
   "hielo"
  ],
  "desc": "Pokémon Transporte. Es muy inteligente y dócil; cruza el mar llevando a personas y Pokémon sobre su lomo.",
  "altura": "2.5 m",
  "peso": "220.0 kg",
  "habilidad": "Absorbe Agua"
 },
 {
  "n": 132,
  "id": "ditto",
  "nombre": "Ditto",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Transform. Puede cambiar su cuerpo a voluntad y copiar el aspecto de cualquier cosa que vea.",
  "altura": "0.3 m",
  "peso": "4.0 kg",
  "habilidad": "Flexibilidad"
 },
 {
  "n": 133,
  "id": "eevee",
  "nombre": "Eevee",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Evolución. Su material genético es inestable, por lo que puede evolucionar de formas muy distintas.",
  "altura": "0.3 m",
  "peso": "6.5 kg",
  "habilidad": "Fuga"
 },
 {
  "n": 134,
  "id": "vaporeon",
  "nombre": "Vaporeon",
  "tipos": [
   "agua"
  ],
  "desc": "Pokémon Burbuja Jet. Su cuerpo es casi como el agua; se vuelve invisible al sumergirse y controla las olas.",
  "altura": "1.0 m",
  "peso": "29.0 kg",
  "habilidad": "Absorbe Agua"
 },
 {
  "n": 135,
  "id": "jolteon",
  "nombre": "Jolteon",
  "tipos": [
   "electrico"
  ],
  "desc": "Pokémon Rayo. Acumula electricidad estática en su pelo, que eriza como agujas para atacar a sus rivales.",
  "altura": "0.8 m",
  "peso": "24.5 kg",
  "habilidad": "Absorbe Elec"
 },
 {
  "n": 136,
  "id": "flareon",
  "nombre": "Flareon",
  "tipos": [
   "fuego"
  ],
  "desc": "Pokémon Llama. Almacena fuego en su cuerpo y lo libera a 900 ºC si se enfurece; su pelo es muy suave.",
  "altura": "0.9 m",
  "peso": "25.0 kg",
  "habilidad": "Absorbe Fuego"
 },
 {
  "n": 137,
  "id": "porygon",
  "nombre": "Porygon",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Virtual. Es el primer Pokémon creado por la ciencia y puede viajar por el ciberespacio.",
  "altura": "0.8 m",
  "peso": "36.5 kg",
  "habilidad": "Rastro"
 },
 {
  "n": 138,
  "id": "omanyte",
  "nombre": "Omanyte",
  "tipos": [
   "roca",
   "agua"
  ],
  "desc": "Pokémon Espiral. Revivido a partir de un fósil, nada con sus tentáculos y se esconde en su concha.",
  "altura": "0.4 m",
  "peso": "7.5 kg",
  "habilidad": "Nado Rápido"
 },
 {
  "n": 139,
  "id": "omastar",
  "nombre": "Omastar",
  "tipos": [
   "roca",
   "agua"
  ],
  "desc": "Pokémon Espiral. Su concha pesada le impide moverse con soltura; se extinguió por no poder cazar bien.",
  "altura": "1.0 m",
  "peso": "35.0 kg",
  "habilidad": "Nado Rápido"
 },
 {
  "n": 140,
  "id": "kabuto",
  "nombre": "Kabuto",
  "tipos": [
   "roca",
   "agua"
  ],
  "desc": "Pokémon Crustáceo. Revivido a partir de un fósil, se esconde en el fondo del mar y apenas ha cambiado en milenios.",
  "altura": "0.5 m",
  "peso": "11.5 kg",
  "habilidad": "Nado Rápido"
 },
 {
  "n": 141,
  "id": "kabutops",
  "nombre": "Kabutops",
  "tipos": [
   "roca",
   "agua"
  ],
  "desc": "Pokémon Crustáceo. Nada ágilmente y usa sus guadañas para cortar a su presa y beber sus fluidos.",
  "altura": "1.3 m",
  "peso": "40.5 kg",
  "habilidad": "Nado Rápido"
 },
 {
  "n": 142,
  "id": "aerodactyl",
  "nombre": "Aerodactyl",
  "tipos": [
   "roca",
   "volador"
  ],
  "desc": "Pokémon Fósil. Es un Pokémon antiguo restaurado a partir del ámbar; vuela por el cielo con enorme ferocidad.",
  "altura": "1.8 m",
  "peso": "59.0 kg",
  "habilidad": "Cabeza Roca"
 },
 {
  "n": 143,
  "id": "snorlax",
  "nombre": "Snorlax",
  "tipos": [
   "normal"
  ],
  "desc": "Pokémon Dormilón. Come casi 400 kg de comida al día y se echa a dormir en cuanto termina; no se mueve más.",
  "altura": "2.1 m",
  "peso": "460.0 kg",
  "habilidad": "Inmunidad"
 },
 {
  "n": 144,
  "id": "articuno",
  "nombre": "Articuno",
  "tipos": [
   "hielo",
   "volador"
  ],
  "desc": "Pokémon Congelar. Es un Pokémon pájaro legendario que puede controlar el hielo; sus alas parecen de cristal.",
  "altura": "1.7 m",
  "peso": "55.4 kg",
  "habilidad": "Presión"
 },
 {
  "n": 145,
  "id": "zapdos",
  "nombre": "Zapdos",
  "tipos": [
   "electrico",
   "volador"
  ],
  "desc": "Pokémon Eléctrico. Es un Pokémon pájaro legendario que vive en las nubes de tormenta y controla los rayos.",
  "altura": "1.6 m",
  "peso": "52.6 kg",
  "habilidad": "Presión"
 },
 {
  "n": 146,
  "id": "moltres",
  "nombre": "Moltres",
  "tipos": [
   "fuego",
   "volador"
  ],
  "desc": "Pokémon Llama. Es un Pokémon pájaro legendario cuyo cuerpo arde; sus alas iluminan el cielo al volar.",
  "altura": "2.0 m",
  "peso": "60.0 kg",
  "habilidad": "Presión"
 },
 {
  "n": 147,
  "id": "dratini",
  "nombre": "Dratini",
  "tipos": [
   "dragon"
  ],
  "desc": "Pokémon Dragón. Cambia de piel varias veces al crecer; durante años se pensó que eran mito.",
  "altura": "1.8 m",
  "peso": "3.3 kg",
  "habilidad": "Mudar"
 },
 {
  "n": 148,
  "id": "dragonair",
  "nombre": "Dragonair",
  "tipos": [
   "dragon"
  ],
  "desc": "Pokémon Dragón. Puede cambiar el clima a su alrededor y vuela con su cuerpo rodeado de un aura brillante.",
  "altura": "4.0 m",
  "peso": "16.5 kg",
  "habilidad": "Mudar"
 },
 {
  "n": 149,
  "id": "dragonite",
  "nombre": "Dragonite",
  "tipos": [
   "dragon",
   "volador"
  ],
  "desc": "Pokémon Dragón. Es capaz de dar la vuelta al mundo en 16 horas y rescata a náufragos en alta mar.",
  "altura": "2.2 m",
  "peso": "210.0 kg",
  "habilidad": "Foco Interno"
 },
 {
  "n": 150,
  "id": "mewtwo",
  "nombre": "Mewtwo",
  "tipos": [
   "psiquico"
  ],
  "desc": "Pokémon Genético. Fue creado a partir de genes de Mew mediante ingeniería genética; es muy poderoso y misterioso.",
  "altura": "2.0 m",
  "peso": "122.0 kg",
  "habilidad": "Presión"
 },
 {
  "n": 151,
  "id": "mew",
  "nombre": "Mew",
  "tipos": [
   "psiquico"
  ],
  "desc": "Pokémon Nueva Especie. Contiene el código genético de todos los Pokémon y puede hacerse invisible a voluntad.",
  "altura": "0.4 m",
  "peso": "4.0 kg",
  "habilidad": "Sincronía"
 }
];

// Cadenas de evolución: cada etapa es una lista de números de Pokédex
var EVOLUCIONES = [[[1], [2], [3]], [[4], [5], [6]], [[7], [8], [9]], [[10], [11], [12]], [[13], [14], [15]], [[16], [17], [18]], [[19], [20]], [[21], [22]], [[23], [24]], [[25], [26]], [[27], [28]], [[29], [30], [31]], [[32], [33], [34]], [[35], [36]], [[37], [38]], [[39], [40]], [[41], [42]], [[43], [44], [45]], [[46], [47]], [[48], [49]], [[50], [51]], [[52], [53]], [[54], [55]], [[56], [57]], [[58], [59]], [[60], [61], [62]], [[63], [64], [65]], [[66], [67], [68]], [[69], [70], [71]], [[72], [73]], [[74], [75], [76]], [[77], [78]], [[79], [80]], [[81], [82]], [[84], [85]], [[86], [87]], [[88], [89]], [[90], [91]], [[92], [93], [94]], [[96], [97]], [[98], [99]], [[100], [101]], [[102], [103]], [[104], [105]], [[109], [110]], [[111], [112]], [[116], [117]], [[118], [119]], [[120], [121]], [[129], [130]], [[138], [139]], [[140], [141]], [[147], [148], [149]], [[133], [134, 135, 136]]];
